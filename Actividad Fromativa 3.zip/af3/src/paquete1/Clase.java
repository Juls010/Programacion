package paquete1;

public class Clase {

	public static void main(String[] args){
		Superclase sc1 = new
		Superclase(); 
		sc1.metodo1();
		//sc1.metodo2(); // ERROR DE VISIBILIDAD
		sc1.metodo3();
		sc1.metodo4();
	}
}
