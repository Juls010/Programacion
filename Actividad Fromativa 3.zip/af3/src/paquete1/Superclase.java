package paquete1;

public class Superclase {
	public void metodo1() {
		System.out.println("M�todo p�blico");
		}
		private void metodo2() {
		System.out.println("M�todo privado");
		}
		protected void metodo3() {
		System.out.println("M�todo protegido");
		}
		void metodo4() {
		System.out.println("M�todo sin modificador");
		}
}
